# shell-script-final-project
final project of IBM course for shell command and linux
Estimated time needed: 90 minutes

Welcome to the hands-on lab for the final project!

In this scenario, you are a lead Linux developer at the top-tech company ABC International Inc. As one of ABC Inc.'s most trusted Linux developers, you have been tasked with creating a script called backup.sh which runs every day and automatically backs up any encrypted password files that have been updated in the past 24 hours.

Please complete the following tasks, and be sure to follow the directions as you go. Don't forget to save your work.

donwload backup file 
wget https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBM-LX0117EN-SkillsNetwork/labs/Final%20Project/backup.sh

TASK 1

Navigate to # [TASK 1] in the code.

Set two variables equal to the values of the first and second command line arguments, as follows:

Set targetDirectory to the first command line argument
Set destinationDirectory to the second command line argument
This task is meant to help with code readability.